from django.apps import AppConfig


class MydesignConfig(AppConfig):
    name = 'mydesign'
