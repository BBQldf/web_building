$(function(){
  $("#fullpage").fullpage({
    sectionsColor:['#ECFFBC','#a29971'],  //section的背景颜色
    // controlArrows:false   滑动箭头控制，默认true
    verticalCentered:false, //页面类容默认垂直居中，默认为true
    scrollingSpeed:800,  //   滑动页面切换速度 默认700毫秒
    anchors:['page1','page2','page3','page4'],
    fixedElements:'#nav',
    navigation:true,position:'right',navigationTooltips:['我的信息','我的评分'],
    afterLoad:function(link, index){
      switch (index) {
        case 2:
            move('.jingli_1').ease('in-out').x(2000).duration(500).end(function(){
              move('.jingli_2').ease('in-out').x(2000).duration(1000).end(function(){
                move('.jingli_3').ease('in-out').x(2000).duration(1000).end(function(){
                  move('.jingli_4').ease('in-out').x(2000).duration(1000).end(function(){
				  move('.jingli_5').ease('in-out').x(2000).duration(1000).end()
				  });
                });
              });
            });
          break;
        default:
          break;
      }
    },
    onLeave:function(link, index){
      switch (index) {
        case 2:
          move('.jingli_1').ease('in').x(-2000).duration(10).end();
          move('.jingli_2').ease('in').x(-2000).duration(10).end();
          move('.jingli_3').ease('in').x(-2000).duration(10).end();
          move('.jingli_4').ease('in').x(-2000).duration(10).end();
		  move('.jingli_5').ease('in').x(-2000).duration(10).end();
          break;
        default:
          break;
      }
    }
  });

})
